"""Claude Haiku を使ったタイトル・要約生成とフォールバック (抽出的生成)。"""
import json
import re
import urllib.request
from collections import Counter

from proc_config import ANTHROPIC_API_KEY, STOP_WORDS, SYNONYMS, normalize, extract_entities


def clean_headline(title):
    """記事タイトルからメディア名サフィックスを除去 例: '記事 - 毎日新聞' → '記事'"""
    return re.sub(r'\s*[-－–|｜]\s*[^\s].{1,20}$', '', title).strip()


def generate_title(articles):
    """Claude Haiku でトピックタイトルを生成。"""
    if not ANTHROPIC_API_KEY:
        return None
    headlines = '\n'.join(clean_headline(a.get('title', '')) for a in articles[:8])
    prompt = (
        '以下はニュース記事の見出しです。\n'
        'これらが共通して報じているトピックを表す、概念的で簡潔な日本語タイトルを作ってください。\n\n'
        '【出力ルール】\n'
        '- 15〜25文字程度の短いタイトル\n'
        '- 「〇〇事件」「△△問題」「△△の動向」「◇◇をめぐる動き」などの形式が望ましい\n'
        '- 記事タイトルをそのままコピーしないこと\n'
        '- メディア名（例: 毎日新聞、NHK等）は絶対に含めないこと\n'
        '- 固有名詞や核心キーワードは必ず含める\n'
        '- 説明文・句読点・かぎかっこ不要。タイトルのみ1行で出力\n\n'
        f'見出し:\n{headlines}'
    )
    try:
        body = json.dumps({
            'model': 'claude-haiku-4-5-20251001',
            'max_tokens': 30,
            'messages': [{'role': 'user', 'content': prompt}],
        }).encode('utf-8')
        req = urllib.request.Request(
            'https://api.anthropic.com/v1/messages',
            data=body,
            headers={
                'x-api-key': ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01',
                'content-type': 'application/json',
            },
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read())
        return data['content'][0]['text'].strip()
    except Exception as e:
        print(f'generate_title error: {e}')
        return None


def generate_summary(articles):
    """Claude Haiku でトピック要約を生成（流れベース）。"""
    if not ANTHROPIC_API_KEY:
        return None
    headlines = '\n'.join(clean_headline(a.get('title', '')) for a in articles[:15])
    article_count = len(articles)
    length_guide = '4〜6文（長期・複雑なトピックは情報量を優先）' if article_count >= 10 else '3〜4文'
    prompt = (
        '以下は同じニューストピックを報じた見出し一覧です。\n'
        'このトピックの「流れ」を把握できる説明を書いてください。\n\n'
        '【構成】\n'
        '1. 何がきっかけで始まったか（発端）\n'
        '2. どう展開し、なぜ注目されたか（経過・背景）\n'
        '3. 現在どうなっているか（今の状況）\n'
        '※ 該当しない場合は省略OK。長期トピック（戦争・裁判等）は経緯を省略しない。\n\n'
        '【ルール】\n'
        f'- 長さ目安: {length_guide}\n'
        '- 記事の羅列ではなく「出来事の流れ」として書く\n'
        '- 重複・類似情報はまとめる\n'
        '- 主観・感想を入れない\n'
        '- メディア名は含めない\n'
        '- 難しい言葉は避ける（わからない人向けに書く）\n'
        '- 【必須】箇条書き（-・*）・番号（1.2.）・見出し（#）・改行区切りは絶対に使わない\n'
        '- 全文を1つの段落として続けて書く（改行禁止）\n\n'
        f'見出し({article_count}件):\n{headlines}'
    )
    try:
        body = json.dumps({
            'model': 'claude-haiku-4-5-20251001',
            'max_tokens': 600,
            'messages': [{'role': 'user', 'content': prompt}],
        }).encode('utf-8')
        req = urllib.request.Request(
            'https://api.anthropic.com/v1/messages',
            data=body,
            headers={
                'x-api-key': ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01',
                'content-type': 'application/json',
            },
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        return data['content'][0]['text'].strip()
    except Exception as e:
        print(f'generate_summary error: {e}')
        return None


def extractive_title(articles):
    """AIを使わないフォールバックタイトル生成。"""
    word_counter = Counter()
    for a in articles:
        words = normalize(a.get('title', '')) - STOP_WORDS
        word_counter.update(w for w in words if len(w) >= 2)
    top_words = [w for w, _ in word_counter.most_common(5) if word_counter[w] >= 2]
    all_text  = ' '.join(a.get('title', '') for a in articles)
    entities  = list(extract_entities(all_text))
    if entities and top_words:
        return f'{entities[0]}と{top_words[0]}をめぐる動き'
    elif entities:
        return f'{entities[0]}に関する動向'
    elif top_words:
        return f'{top_words[0]}をめぐる動き'
    else:
        first = articles[0].get('title', '') if articles else ''
        return first[:25] + ('…' if len(first) > 25 else '')

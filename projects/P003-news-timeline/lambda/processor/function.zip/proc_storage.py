"""DynamoDB / S3 アクセス層と Slack 通知。"""
import json
import urllib.request
from decimal import Decimal

from boto3.dynamodb.conditions import Key

from proc_config import S3_BUCKET, SLACK_WEBHOOK, table, s3


def get_pending_topics(max_topics=100):
    """S3のpending_ai.jsonからトピックIDを取得し、DynamoDBで個別に取得。"""
    pending_ids = []
    if S3_BUCKET:
        try:
            resp = s3.get_object(Bucket=S3_BUCKET, Key='api/pending_ai.json')
            data = json.loads(resp['Body'].read())
            pending_ids = data.get('topicIds', [])
        except Exception:
            pass

    if pending_ids:
        items = []
        for tid in pending_ids[:max_topics * 2]:
            try:
                r = table.get_item(
                    Key={'topicId': tid, 'SK': 'META'},
                    ProjectionExpression='topicId,title,articleCount,score,velocityScore,generatedTitle,generatedSummary,aiGenerated',
                )
                item = r.get('Item')
                if item and not item.get('aiGenerated'):
                    items.append(item)
            except Exception:
                pass
        items.sort(key=lambda x: int(x.get('score', 0) or 0), reverse=True)
        return items[:max_topics]

    # フォールバック: DynamoDBスキャン（pending_ai.json未作成時のみ）
    print('get_pending_topics: S3未作成のためDynamoDBフォールバック')
    items, kwargs = [], {
        'FilterExpression':        'SK = :m AND pendingAI = :t',
        'ExpressionAttributeValues': {':m': 'META', ':t': True},
        'ProjectionExpression':    'topicId,title,articleCount,score,velocityScore,generatedTitle,generatedSummary,aiGenerated',
    }
    while True:
        r = table.scan(**kwargs)
        items.extend(r.get('Items', []))
        if not r.get('LastEvaluatedKey'): break
        kwargs['ExclusiveStartKey'] = r['LastEvaluatedKey']
    items.sort(key=lambda x: int(x.get('score', 0) or 0), reverse=True)
    return items[:max_topics]


def get_latest_articles_for_topic(tid):
    """最新SNAPを優先しつつ過去スナップも合わせて最大20件の記事を返す（重複排除済み）。"""
    try:
        r = table.query(
            KeyConditionExpression=Key('topicId').eq(tid) & Key('SK').begins_with('SNAP#'),
            ScanIndexForward=False,
            Limit=5,
        )
        seen_urls = set()
        articles = []
        for item in r.get('Items', []):
            for a in item.get('articles', []):
                url = a.get('url', '')
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    articles.append(a)
                    if len(articles) >= 20:
                        return articles
        return articles
    except Exception as e:
        print(f'get_latest_articles_for_topic error [{tid}]: {e}')
    return []


def update_topic_with_ai(tid, gen_title, gen_summary):
    """Claude 生成タイトル・要約で DynamoDB META を更新し、pendingAI をクリア。"""
    try:
        update_expr  = 'SET aiGenerated = :t, pendingAI = :f'
        expr_values  = {':t': True, ':f': False}
        if gen_title:
            update_expr += ', generatedTitle = :title'
            expr_values[':title'] = gen_title
        if gen_summary:
            update_expr += ', generatedSummary = :summary'
            expr_values[':summary'] = gen_summary
        table.update_item(
            Key={'topicId': tid, 'SK': 'META'},
            UpdateExpression=update_expr,
            ExpressionAttributeValues=expr_values,
        )
    except Exception as e:
        print(f'update_topic_with_ai error [{tid}]: {e}')


def get_all_topics_for_s3():
    """S3のtopics.jsonから読む（DynamoDBフルスキャン不要）。"""
    if S3_BUCKET:
        try:
            resp = s3.get_object(Bucket=S3_BUCKET, Key='api/topics.json')
            data = json.loads(resp['Body'].read())
            items = data.get('topics', [])
            if items:
                return items
        except Exception as e:
            print(f'get_all_topics_for_s3 S3 error: {e}')
    items, kwargs = [], {
        'FilterExpression': 'SK = :m',
        'ExpressionAttributeValues': {':m': 'META'},
    }
    while True:
        r = table.scan(**kwargs)
        items.extend(r.get('Items', []))
        if not r.get('LastEvaluatedKey'): break
        kwargs['ExclusiveStartKey'] = r['LastEvaluatedKey']
    items.sort(key=lambda x: int(x.get('score', 0) or 0), reverse=True)
    return items


def dec_convert(obj):
    if isinstance(obj, Decimal): return int(obj)
    raise TypeError


def write_s3(key, data):
    if not S3_BUCKET:
        return
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=key,
        Body=json.dumps(data, default=dec_convert, ensure_ascii=False).encode('utf-8'),
        ContentType='application/json',
        CacheControl='max-age=60',
    )


def notify_slack_error(error_msg: str):
    if not SLACK_WEBHOOK:
        return
    try:
        msg = f'🚨 *Processor エラー*\n{error_msg}'
        body = json.dumps({'text': msg}).encode('utf-8')
        req  = urllib.request.Request(
            SLACK_WEBHOOK, data=body,
            headers={'Content-Type': 'application/json'}, method='POST',
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp.read()
    except Exception as e:
        print(f'Slack通知エラー: {e}')

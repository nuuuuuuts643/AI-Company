import json
import re
import time
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from config import (
    SLACK_WEBHOOK, S3_BUCKET,
    RSS_FEEDS, SNAP_TTL_DAYS, table, INACTIVE_LIFECYCLE_STATUSES,
)
from text_utils import (
    topic_fingerprint, dominant_genres, dominant_lang,
    extract_source_name, extract_rss_image, cluster,
    calc_score, calc_velocity_score, apply_time_decay,
    source_diversity_score, compute_lifecycle_status,
    sort_by_pubdate, extract_trending_keywords,
    extract_entities, find_related_topics, detect_topic_hierarchy,
    extractive_title, extractive_summary,
    _parse_pubdate_ts,
)
from storage import (
    write_s3, get_all_topics, get_topic_detail,
    recent_counts, calc_velocity, validate_topics_exist,
    load_seen_articles, save_seen_articles,
    generate_rss, generate_sitemap,
)


def fetch_rss(feed):
    articles = []
    url, genre, lang = feed['url'], feed['genre'], feed.get('lang', 'ja')
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Flotopic/1.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read()
        root = ET.fromstring(content)
        for item in root.findall('.//item'):
            title   = (item.findtext('title')   or '').strip()
            link    = (item.findtext('link')     or '').strip()
            pubdate = (item.findtext('pubDate')  or '').strip()
            img     = extract_rss_image(item)
            if title and link:
                articles.append({
                    'title':        title, 'url': link,
                    'pubDate':      pubdate, 'genre': genre,
                    'lang':         lang,
                    'source':       extract_source_name(item, link, url),
                    'imageUrl':     img,
                    'published_ts': _parse_pubdate_ts(pubdate),
                })
    except Exception as e:
        print(f'RSS error [{url}]: {e}')
    return articles


def fetch_ogp_image(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Flotopic/1.0'})
        with urllib.request.urlopen(req, timeout=2) as resp:
            html = resp.read(16384).decode('utf-8', errors='ignore')
        m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
        if m: return m.group(1)
        m = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']', html, re.I)
        if m: return m.group(1)
    except Exception:
        pass
    return None


def find_trending_spikes(groups_meta_list):
    spikes = []
    for articles, tid, cnt, hist_with_ts in groups_meta_list:
        if cnt < 5 or not hist_with_ts:
            continue
        prev_counts = [c for c, _ in hist_with_ts]
        avg_prev = sum(prev_counts) / len(prev_counts)
        if avg_prev > 0 and cnt > 3 * avg_prev:
            spikes.append({'title': articles[0]['title'], 'count': cnt, 'avg_prev': avg_prev})
    return spikes


def post_slack_spike(spikes):
    if not SLACK_WEBHOOK or not spikes:
        return
    message = '\n'.join(
        '\U0001f525 急上昇トピック検出: ' + s['title'] + ' (' + str(s['count']) + '件)'
        for s in spikes
    )
    try:
        body = json.dumps({'text': message}).encode('utf-8')
        req = urllib.request.Request(
            SLACK_WEBHOOK, data=body,
            headers={'Content-Type': 'application/json'}, method='POST',
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp.read()
        print(f'Slack spike alert sent: {len(spikes)}件')
    except Exception as e:
        print(f'Slack spike alert error: {e}')


def calc_status(history_with_ts, current):
    counts = list(reversed([c for c, _ in history_with_ts])) + [current]
    if len(counts) < 2:
        return 'rising'
    diff = counts[-1] - counts[0]
    count_diff_recent = current - history_with_ts[0][0] if history_with_ts else diff
    if diff > 0 or count_diff_recent > 0:
        return 'rising'
    if diff < -1:
        return 'declining'
    return 'peak'


def _prefetch_group(tid):
    """DynamoDB から hist と既存 META を同時取得。"""
    hist     = recent_counts(tid)
    existing = table.get_item(Key={'topicId': tid, 'SK': 'META'}).get('Item', {})
    return hist, existing


def _fetch_ogp_group(tid, urls):
    """複数 URL を順番に試して最初に取得できた OGP 画像を返す。"""
    for u in urls:
        img = fetch_ogp_image(u)
        if img:
            return tid, img
    return tid, None


def lambda_handler(event, context):
    # Step 1: 前回既知 URL を読み込む（差分更新用）
    seen_urls = load_seen_articles()

    # Step 2: 全 RSS フィードを並列取得
    all_articles = []
    with ThreadPoolExecutor(max_workers=15) as ex:
        fs = {ex.submit(fetch_rss, feed): feed for feed in RSS_FEEDS}
        for f in as_completed(fs):
            feed = fs[f]
            try:
                fetched = f.result()
                all_articles.extend(fetched)
                print(f'[{feed["genre"]}] {feed["url"].split("/")[2]}: {len(fetched)}件')
            except Exception as e:
                print(f'RSS error [{feed["url"]}]: {e}')

    print(f'合計: {len(all_articles)}記事')

    # Step 3: 差分チェック
    current_urls = {a['url'] for a in all_articles}
    new_urls     = current_urls - seen_urls

    if seen_urls and not new_urls:
        print('新規記事なし。DynamoDB 呼び出しをスキップします。')
        save_seen_articles(current_urls)
        return {'statusCode': 200,
                'body': json.dumps({'articles': len(all_articles), 'new': 0, 'skipped': True})}

    print(f'新規記事: {len(new_urls)}件 / 既知: {len(seen_urls)}件')
    save_seen_articles(current_urls)

    groups = cluster(all_articles)
    print(f'トピック数: {len(groups)}')

    groups_sorted = sorted(groups, key=lambda g: len({a['source'] for a in g}) * 10, reverse=True)
    group_tids    = [(g, topic_fingerprint(g)) for g in groups_sorted]

    # Step 4: DynamoDB（hist + META）を全グループ並列プリフェッチ
    prefetched = {}
    with ThreadPoolExecutor(max_workers=20) as ex:
        fs = {ex.submit(_prefetch_group, tid): tid for _, tid in group_tids}
        for f in as_completed(fs):
            tid = fs[f]
            try:
                prefetched[tid] = f.result()
            except Exception:
                prefetched[tid] = ([], {})

    # Step 5: OGP 画像が必要なグループを特定して並列取得（最大 20 件）
    ogp_candidates = []
    for g, tid in group_tids:
        _, existing = prefetched.get(tid, ([], {}))
        if existing.get('imageUrl') or any(a.get('imageUrl') for a in g):
            continue
        if len(g) < 2:
            continue
        jp_urls    = [a['url'] for a in g if '.jp' in a.get('url', '')]
        check_urls = jp_urls[:2] + [a['url'] for a in g[:3] if a['url'] not in jp_urls]
        if check_urls:
            ogp_candidates.append((tid, check_urls[:3]))

    ogp_results = {}
    with ThreadPoolExecutor(max_workers=10) as ex:
        fs = [ex.submit(_fetch_ogp_group, tid, urls) for tid, urls in ogp_candidates[:20]]
        for f in as_completed(fs):
            try:
                tid, img = f.result()
                if img:
                    ogp_results[tid] = img
            except Exception:
                pass

    now    = datetime.now(timezone.utc)
    ts_key = now.strftime('%Y%m%dT%H%M%SZ')
    ts_iso = now.isoformat()

    saved_ids        = []
    current_run_metas = {}  # {tid: item} 今回のrunで書いたMETAアイテム
    groups_meta_list = []

    # Step 6: メインループ（外部 I/O なし・DynamoDB 書き込みのみ）
    for g, tid in group_tids:
        cnt    = len(g)
        genres = dominant_genres(g)
        genre  = genres[0]
        lang   = dominant_lang(g)
        hist, existing = prefetched.get(tid, ([], {}))

        groups_meta_list.append((g, tid, cnt, hist))
        st             = calc_status(hist, cnt)
        score, media, hb = calc_score(g)

        last_article_ts = max((a.get('published_ts', 0) for a in g), default=0)
        score = apply_time_decay(score, last_article_ts)
        score = max(1, int(score * source_diversity_score(g)))
        velocity_score  = calc_velocity_score(g)

        if existing.get('aiGenerated') and existing.get('generatedTitle'):
            gen_title = existing['generatedTitle']
        else:
            gen_title = existing.get('generatedTitle') or extractive_title(g)

        existing_summary  = existing.get('generatedSummary', '')
        _is_old_extractive = existing_summary and '複数の報道' in existing_summary and '関連して' in existing_summary
        if existing.get('aiGenerated') and existing_summary and not _is_old_extractive:
            gen_summary = existing_summary
        else:
            gen_summary = extractive_summary(g) if cnt >= 3 else None

        pending_ai = not bool(
            existing.get('aiGenerated') and existing.get('generatedSummary') and not _is_old_extractive
        )

        image_url = (
            existing.get('imageUrl') or
            next((a.get('imageUrl') for a in g if a.get('imageUrl')), None) or
            ogp_results.get(tid)
        )

        velocity = calc_velocity(hist, cnt, ts_iso)

        if existing.get('lifecycleStatus') == 'legacy':
            lifecycle_status = 'legacy'
        else:
            lifecycle_status = compute_lifecycle_status(score, last_article_ts, velocity_score, cnt)

        item = {
            'topicId':         tid,
            'SK':              'META',
            'title':           g[0]['title'],
            'generatedTitle':  gen_title or g[0]['title'],
            'status':          st,
            'genre':           genre,
            'genres':          genres,
            'lang':            lang,
            'articleCount':    cnt,
            'mediaCount':      media,
            'hatenaCount':     hb,
            'score':           score,
            'velocity':        velocity,
            'velocityScore':   velocity_score,
            'lastUpdated':     ts_iso,
            'lastArticleAt':   last_article_ts,
            'lifecycleStatus': lifecycle_status,
            'sources':         list({a['source'] for a in g}),
            'pendingAI':       pending_ai,
        }
        if gen_summary:                 item['generatedSummary'] = gen_summary
        if image_url:                   item['imageUrl']         = image_url
        if existing.get('aiGenerated'): item['aiGenerated']      = True
        table.put_item(Item=item)
        current_run_metas[tid] = item
        table.put_item(Item={
            'topicId':      tid,
            'SK':           f'SNAP#{ts_key}',
            'articleCount': cnt,
            'score':        score,
            'hatenaCount':  hb,
            'mediaCount':   media,
            'timestamp':    ts_iso,
            'ttl':          int(time.time()) + SNAP_TTL_DAYS * 86400,
            'articles': sort_by_pubdate(list({
                a['source']: {
                    'title':       a['title'], 'url': a['url'],
                    'source':      a['source'], 'pubDate': a['pubDate'],
                    'publishedAt': a.get('published_ts', 0),
                } for a in g
            }.values()))[:20],
        })
        saved_ids.append(tid)

    if S3_BUCKET:
        topics = get_all_topics()

        # 今回のrun で書いたトピック（DynamoDB確定）をtopics.jsonにマージ
        existing_tids = {t['topicId'] for t in topics}
        for item in current_run_metas.values():
            if item['topicId'] not in existing_tids:
                topics.append(item)
                existing_tids.add(item['topicId'])

        # 幽霊エントリ除去: 今回runで書いたtopicはDynamoDB確定なのでスキップ
        saved_tids = set(saved_ids)
        pre_count  = len(topics)
        topics     = validate_topics_exist(topics, skip_tids=saved_tids)
        if len(topics) < pre_count:
            print(f'幽霊エントリ除去: {pre_count - len(topics)}件削除')

        topics_active = [t for t in topics if t.get('lifecycleStatus', 'active') not in INACTIVE_LIFECYCLE_STATUSES]
        topics_active = sorted(topics_active, key=lambda x: int(x.get('score', 0) or 0), reverse=True)[:1000]
        print(f'O(n²)処理対象: {len(topics_active)}件 / 全{len(topics)}件')

        related_map = find_related_topics(topics_active)
        for t in topics:
            t['relatedTopics'] = related_map.get(t.get('topicId', ''), [])

        topic_entities_map = {
            t['topicId']: extract_entities(t.get('generatedTitle') or t.get('title', ''))
            for t in topics_active
        }
        parent_map = detect_topic_hierarchy(topics_active, topic_entities_map)

        child_to_parent  = {}
        parent_to_children = {}
        for tid_b, tid_a in parent_map.items():
            child_to_parent[tid_b] = tid_a
            parent_to_children.setdefault(tid_a, [])
            child_t = next((t for t in topics if t['topicId'] == tid_b), None)
            if child_t:
                parent_to_children[tid_a].append({
                    'topicId': tid_b,
                    'title':   child_t.get('generatedTitle') or child_t.get('title', ''),
                })

        for t in topics:
            tid = t['topicId']
            if tid in child_to_parent:   t['parentTopicId'] = child_to_parent[tid]
            if tid in parent_to_children: t['childTopics']   = parent_to_children[tid]

        def _norm_title(t):
            s = (t.get('generatedTitle') or t.get('title', '')).strip()
            s = s.replace('｢', '「').replace('｣', '」').replace('　', ' ')
            s = re.sub(r'\s+', ' ', s)
            s = re.sub(r'\s*[-－–|｜]\s*[^\s].{1,25}$', '', s)
            return s.lower()[:50]

        def _core_key(t):
            s = (t.get('generatedTitle') or t.get('title', '')).lower()
            s = re.sub(r'[「」【】・、。,!?！？\[\]()（）『』""\'\'#＃]', '', s)
            s = re.sub(r'\s+', '', s)
            return s[:18]

        dedup_long = {}
        dedup_core = {}
        for t in topics:
            kl = _norm_title(t)
            kc = _core_key(t)
            sc = int(t.get('score', 0) or 0)
            if kl in dedup_long:
                if sc > int(dedup_long[kl].get('score', 0) or 0):
                    dedup_long[kl] = t
                    dedup_core[kc] = t
            elif kc in dedup_core:
                if sc > int(dedup_core[kc].get('score', 0) or 0):
                    old_kl = _norm_title(dedup_core[kc])
                    dedup_long.pop(old_kl, None)
                    dedup_long[kl] = t
                    dedup_core[kc] = t
            else:
                dedup_long[kl] = t
                dedup_core[kc] = t

        topics_deduped_all = sorted(dedup_long.values(), key=lambda x: int(x.get('score', 0) or 0), reverse=True)
        topics_deduped     = [t for t in topics_deduped_all if t.get('lifecycleStatus', 'active') not in INACTIVE_LIFECYCLE_STATUSES][:2000]

        write_s3('api/topics.json', {
            'topics':          topics_deduped,
            'trendingKeywords': extract_trending_keywords(topics_deduped),
            'updatedAt':       ts_iso,
        })

        topic_map   = {t['topicId']: t for t in topics}
        pending_ids = [tid for tid in saved_ids
                       if not (topic_map.get(tid, {}).get('aiGenerated') and
                               topic_map.get(tid, {}).get('generatedSummary'))]
        write_s3('api/pending_ai.json', {'topicIds': pending_ids, 'updatedAt': ts_iso})
        generate_rss(topics, ts_iso)
        generate_sitemap(topics)

        s3_written = 0
        for tid in saved_ids:
            meta, snaps, views = get_topic_detail(tid)
            if meta:
                s3_written += 1
                meta['relatedTopics'] = related_map.get(tid, [])
                if tid in child_to_parent:   meta['parentTopicId'] = child_to_parent[tid]
                if tid in parent_to_children: meta['childTopics']   = parent_to_children[tid]
                write_s3(f'api/topic/{tid}.json', {
                    'meta': meta,
                    'timeline': [
                        {'timestamp':    s['timestamp'],
                         'articleCount': s['articleCount'],
                         'score':        s.get('score', 0),
                         'hatenaCount':  s.get('hatenaCount', 0),
                         'articles':     s.get('articles', [])}
                        for s in snaps
                    ],
                    'views': [
                        {'date': v['date'], 'count': int(v.get('count', 0))}
                        for v in views
                    ],
                })
        print(f'S3書き出し完了: {s3_written}件')

    spikes = find_trending_spikes(groups_meta_list)
    if spikes:
        post_slack_spike(spikes)

    save_seen_articles(current_urls)

    return {'statusCode': 200,
            'body': json.dumps({'articles': len(all_articles), 'new': len(new_urls),
                                'topics': len(groups_sorted), 'ts': ts_key})}
